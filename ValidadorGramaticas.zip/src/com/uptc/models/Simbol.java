package com.uptc.models;

public interface Simbol {
    
    public String getPathImage();

    public String getSimbol();

}
